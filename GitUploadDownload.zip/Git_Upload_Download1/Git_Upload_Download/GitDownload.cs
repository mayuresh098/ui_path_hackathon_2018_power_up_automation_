﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace Git_Upload_Download
{


    public class Committer

    {
        public string name { get; set; }
        public string email { get; set; }
    }

    public class RootObject
    {
        public string message { get; set; }
        public Committer committer { get; set; }
        public string content { get; set; }
    }

    public class respon
    {
        public string content { get; set; }
    }



    public class GitDownload : CodeActivity
    {
        [DisplayName("Working Directory"), Category("Input"), Description("Working Directory")]
        public InArgument<String> WorkingDirectory { get; set; }

        [DisplayName("File Name"), Category("Input"), Description("To Be Downloaded From Git")]
        public InArgument<String> FileName { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            String strWorkingDirectory = WorkingDirectory.Get(context);
            String strFileName = FileName.Get(context);

            if (Directory.Exists(strWorkingDirectory))
            {

            }
            else
            {
                try
                {
                    Directory.CreateDirectory(strWorkingDirectory);
                }
                catch (Exception e)
                {
                    throw new System.Exception(e.Message);
                }
            }

            if (strFileName.ToLower().Contains(".xaml"))
            {
                strWorkingDirectory = strWorkingDirectory + strFileName;
            }
            else
            {
                strFileName = strFileName + ".xaml";
                strWorkingDirectory = strWorkingDirectory + strFileName;
            }
            strFileName = "http://api.github.com/repos/peetsprideC137/Portfol/contents/" + strFileName;

            Console.WriteLine(strFileName);
            Console.WriteLine(strWorkingDirectory);

            CallWebAPIAsync(strFileName, strWorkingDirectory);

        }


        static void CallWebAPIAsync(String gitFilePath, String DestFilePath)
        {
            using (var client = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = false; ServicePointManager.MaxServicePointIdleTime = 0;
                ServicePointManager.MaxServicePointIdleTime = 2000;

                client.DefaultRequestHeaders.Accept.Clear();

                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("Mozilla", "5.0"));

                var byteArray = Encoding.ASCII.GetBytes("varghesepeter1089@gmail.com : 454beea2c01760826a5a9a1501dd2fc0abc492ac");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                HttpResponseMessage response = client.GetAsync(gitFilePath).GetAwaiter().GetResult();
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("4");
                    respon p = response.Content.ReadAsAsync<respon>().GetAwaiter().GetResult();
                    byte[] b = Convert.FromBase64String(p.content);
                    var strOriginal = System.Text.Encoding.UTF8.GetString(b);
                    File.WriteAllText(DestFilePath, strOriginal);
                }

                else
                {
                    throw new System.Exception("Git Error");
                }
                Console.WriteLine("5");
            }
        }
    }


    public class GitUpload : CodeActivity
    {
        [DisplayName("File Name"), Category("Input"), Description("XAML File Path")]
        public InArgument<String> FilePath { get; set; }

        [DisplayName("Git ID"), Category("Input"), Description("To Be Generated From API")]
        public InArgument<String> GitID { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            String FilePath1 = FilePath.Get(context);
            String GitID1 = GitID.Get(context);
            PUTReq(FilePath1, GitID1);
        }

        static void PUTReq(String Path, String GitID)
        {
            using (var clientPut = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = false; ServicePointManager.MaxServicePointIdleTime = 0;
                ServicePointManager.MaxServicePointIdleTime = 2000;

                Byte[] bytes = File.ReadAllBytes(Path);
                String test = Convert.ToBase64String(bytes);

                clientPut.DefaultRequestHeaders.Accept.Clear();

                clientPut.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("Mozilla", "5.0"));


                var byteArray = Encoding.ASCII.GetBytes("varghesepeter1089@gmail.com:454beea2c01760826a5a9a1501dd2fc0abc492ac");


                clientPut.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                Committer com = new Committer() { email = "varghesepeter1089@gmail.com", name = "peetsprideC137" };

                var root = new RootObject() { message = "this is the end", content = test, committer = com };
                String httpUrl = "https://api.github.com/repos/peetsprideC137/Portfol/contents/amit/" + GitID + ".xaml";

                HttpResponseMessage response = clientPut.PutAsJsonAsync(httpUrl, root).GetAwaiter().GetResult();

                if (response.IsSuccessStatusCode)
                {

                }
                else
                {
                    throw new System.Exception("Error Occured While Upload");
                }
            }
        }
    }
}
