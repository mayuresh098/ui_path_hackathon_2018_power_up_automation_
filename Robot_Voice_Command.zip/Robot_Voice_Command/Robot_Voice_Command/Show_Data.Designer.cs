﻿namespace Robot_Voice_Command
{
    partial class Show_Data
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtShowToForm = new System.Windows.Forms.DataGridView();
            this.ok = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtShowToForm)).BeginInit();
            this.SuspendLayout();
            // 
            // dtShowToForm
            // 
            this.dtShowToForm.AllowUserToAddRows = false;
            this.dtShowToForm.AllowUserToDeleteRows = false;
            this.dtShowToForm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtShowToForm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtShowToForm.Location = new System.Drawing.Point(12, 12);
            this.dtShowToForm.Name = "dtShowToForm";
            this.dtShowToForm.Size = new System.Drawing.Size(776, 397);
            this.dtShowToForm.TabIndex = 0;
            // 
            // ok
            // 
            this.ok.Location = new System.Drawing.Point(632, 415);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(75, 23);
            this.ok.TabIndex = 1;
            this.ok.Text = "Submit";
            this.ok.UseVisualStyleBackColor = true;
            this.ok.Click += new System.EventHandler(this.ok_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(713, 415);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 2;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // Show_Data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.dtShowToForm);
            this.Name = "Show_Data";
            this.Text = "Show_Data";
            this.Load += new System.EventHandler(this.Show_Data_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtShowToForm)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtShowToForm;
        private System.Windows.Forms.Button ok;
        private System.Windows.Forms.Button cancel;
    }
}