﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Robot_Voice_Command
{
    public partial class Show_Data : Form
    {
        public static DataTable dt;
        public Show_Data()
        {
            InitializeComponent();
        }

        private void Show_Data_Load(object sender, EventArgs e)
        {
            dtShowToForm.DataSource = ExecuteRobot.table;
        }

        private void ok_Click(object sender, EventArgs e)
        {
            dt = (DataTable)dtShowToForm.DataSource;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            dt = (DataTable)dtShowToForm.DataSource;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
