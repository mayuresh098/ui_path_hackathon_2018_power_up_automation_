﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.IO;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;

namespace Robot_Voice_Command
{
    public partial class Form1 : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer synthesizer = new SpeechSynthesizer();

        String WorkingLocation=@"E:\Custom\";


        public void AssignComboBox()
        {
            String [] xamlFiles = Directory.GetFiles(WorkingLocation, "*.xaml");
            comboBox1.DisplayMember = "Text";
            comboBox1.ValueMember = "Value";
            List<Object> items = new List<Object>();
            foreach (String file in xamlFiles)
            {
                items.Add(new { Text = file.Substring(file.LastIndexOf("\\") + 1), Value = file });
            }
            comboBox1.DataSource = items;
        }


        public Form1()
        {
            InitializeComponent();
        }
        void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            textBox1.Text = e.Result.Text;
            String xamlPath= WorkingLocation+ e.Result.Text;
            if (CheckandUpload(xamlPath))
            {

            }
        }

        public Boolean CheckandUpload(String xamlPath)
        {
            if (xamlPath.ToLower().Contains(".xaml"))
            {

            }
            else
            {
                xamlPath = xamlPath + ".xaml";
            }
            String strPath = xamlPath;
            if(File.Exists(strPath))
            {
                ExecuteRobot.XAMLRead(strPath);
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            recEngine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(engine_SpeechRecognized);
            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            textBox1.Text= recEngine.AudioLevel.ToString();
        }

        void engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            recEngine.RecognizeAsyncStop();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AssignComboBox();
            try
            {
                Choices commands = new Choices();
                commands.Add(new string[] { "Gmail", "Outlook", "AMAZON"});
                GrammarBuilder gBuilder = new GrammarBuilder();
                gBuilder.Append(commands);
                Grammar grammar = new Grammar(gBuilder);

                recEngine.LoadGrammarAsync(grammar);
                recEngine.SetInputToDefaultAudioDevice();
                recEngine.SpeechRecognized += recEngine_SpeechRecognized;
            }
            catch
            {

            }
        }

        public static void ExecuteCommand(string Command)
        {
            Process Process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "C:\\Program Files\\UiPath\\Studio\\UiRobot.exe",
                    Arguments = "-file " + Command,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true,
                }
            };

            Process.Start();
            Process.WaitForExit();
        }

        public class ServerResponse
        {
            public string message { get; set; }
        }

        public class Committer

        {
            public string name { get; set; }
            public string email { get; set; }
        }

        public class RootObject
        {
            public string message { get; set; }
            public Committer committer { get; set; }
            public string content { get; set; }
        }

        public class respon
        {
            public string content { get; set; }
        }

        static async Task CallWebAPIAsync(String gitFilePath, String DestFilePath)
        {
            using (var client = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = false; ServicePointManager.MaxServicePointIdleTime = 0;
                ServicePointManager.MaxServicePointIdleTime = 2000;

                client.DefaultRequestHeaders.Accept.Clear();

                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("Mozilla", "5.0"));

                var byteArray = Encoding.ASCII.GetBytes("varghesepeter1089@gmail.com : 454beea2c01760826a5a9a1501dd2fc0abc492ac");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                HttpResponseMessage response = await client.GetAsync(gitFilePath);

                if (response.IsSuccessStatusCode)
                {
                    respon p = await response.Content.ReadAsAsync<respon>();
                    byte[] b = Convert.FromBase64String(p.content);
                    var strOriginal = System.Text.Encoding.UTF8.GetString(b);
                    File.WriteAllText(DestFilePath, strOriginal);
                }

                else
                {
                    
                }
            }
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            String path = comboBox1.SelectedValue.ToString();
            CheckandUpload(path);
        }

        public String runHttp(String s)
        {
            String url= "https://app.attraction11.hasura-app.io/show/?query="+s;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            
            // Get the stream associated with the response.
            Stream receiveStream = response.GetResponseStream();

            // Pipes the stream to a higher level stream reader with the required encoding format. 
            StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);

            String jsonResp=readStream.ReadToEnd();
            
            response.Close();
            readStream.Close();
            return jsonResp;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String Task = textBox1.Text;
            String xamlPath = WorkingLocation + Task;
            if(xamlPath.ToLower().Contains("xaml"))
            {

            }
            else
            {
                xamlPath = xamlPath + ".xaml";
            }
            if (CheckandUpload(xamlPath))
            {

            }
            else
            {
                String hash = runHttp(Task);
                String gitFileName = "http://api.github.com/repos/peetsprideC137/Portfol/contents/" + hash+".xaml";
                CallWebAPIAsync(gitFileName, xamlPath);
                ExecuteRobot.XAMLRead(xamlPath);
            }
        }
    }
}
