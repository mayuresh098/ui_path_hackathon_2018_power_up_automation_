﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Robot_Voice_Command
{
    class ExecuteRobot
    {
        public static DataTable table;

        
        public static void XAMLWrite(String Path, DataTable table)
        {
                String TempXAML="";
                String PermXAML="";
                String[] xamlText = File.ReadAllLines(Path);
                foreach (String s in xamlText)
                {
                int i = 0;
                if (s.ToLower().Contains("<activity"))
                    {
                        String[] arrThis = s.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                        bool flag = false;
                    
                    foreach (String s1 in arrThis)
                    {
                        String temps1 = s1;
                        if (flag)
                        {
                            int indexOfDot = temps1.IndexOf(".");
                            int indexOfEqual = temps1.IndexOf("=");
                            String Key = temps1.Substring(indexOfDot + 1, indexOfEqual - indexOfDot - 1);
                            String Value = temps1.Substring(indexOfEqual + 1, temps1.LastIndexOf("\"") - indexOfEqual - 1);
                            if (Key.ToLower().Contains("staticComplete") || Key.ToLower().Contains("default"))
                            {

                            }
                            else if (Key.ToLower().Contains("static"))
                            {
                                foreach (DataRow row in table.Rows)
                                {
                                    if (row[1].ToString() == Key)
                                    {
                                        temps1 = temps1.Remove(indexOfEqual+2, temps1.LastIndexOf("\"") - indexOfEqual - 2);
                                        temps1 = temps1.Insert(indexOfEqual+2, row[2].ToString());
                                    }
                                }
                            }
                            else
                            {
                                foreach (DataRow row in table.Rows)
                                {
                                    if (row[1].ToString() == Key)
                                    {
                                        temps1 = temps1.Remove(indexOfEqual + 1, temps1.LastIndexOf("\"") - indexOfEqual - 2);
                                        temps1 = temps1.Insert(indexOfEqual + 1, row[2].ToString());
                                    }
                                }
                            }
                            flag = false;
                        }
                                if (s1.ToLower().Contains("this"))
                                {
                                    flag = true;
                                }
                        if (String.IsNullOrEmpty(TempXAML))
                        {
                            TempXAML = TempXAML + temps1;
                        }
                        else
                        {
                            TempXAML = TempXAML +":"+ temps1;
                        }
                        i++;
                        }
                    }
                if (i== 0)
                {
                    TempXAML = TempXAML+ Environment.NewLine + s;
                    i = 0;
                }
            }
            File.WriteAllText(Path, TempXAML);
        }

          public static void XAMLRead(String Path)
        {
            table = new DataTable();
            table.Clear();
                table.Columns.Add("type", typeof(string));
                table.Columns.Add("Key", typeof(string));
                table.Columns.Add("Value", typeof(string));

            try
            {
                String [] xamlText = File.ReadAllLines(Path);
                Boolean isBreak= false ;
                foreach (String s in xamlText)
                {
                    if (s.ToLower().Contains("<activity"))
                    {
                        String[] arrThis = s.Split(new char[] {':'}, StringSplitOptions.RemoveEmptyEntries);
                        int i = 0;
                        foreach(String s1 in arrThis)
                        {
                            if (s1.ToLower().Contains("this"))
                            {
                                String temp = arrThis[i+1];
                                int indexOfDot = temp.IndexOf(".");
                                int indexOfEqual = temp.IndexOf("=");
                                String Key = temp.Substring(indexOfDot+1, indexOfEqual - indexOfDot-1);
                                String Value = temp.Substring(indexOfEqual+1, temp.LastIndexOf("\"")-indexOfEqual-1);
                                if (Key.ToLower().Contains("staticComplete") || Key.ToLower().Contains("default"))
                                {
                                    
                                }
                                else if (Key.ToLower().Contains("static"))
                                {
                                    table.Rows.Add("static", Key, Value.Replace("\"",""));
                                }
                                else
                                {
                                    table.Rows.Add("dynamic", Key, Value.Replace("\"", ""));
                                }
                            }
                            i++;
                        }

                        Show_Data show2 = new Show_Data();
                        DialogResult result= show2.ShowDialog();
                        isBreak = true;
                    }
                    if (isBreak)
                    {
                        break;
                    }
                }
                XAMLWrite(Path, Show_Data.dt);
            }
            catch(Exception e)
            {

            }
        }
    }
}
