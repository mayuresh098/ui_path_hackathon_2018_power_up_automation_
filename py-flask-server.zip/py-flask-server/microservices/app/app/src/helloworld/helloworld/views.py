from django.http import HttpResponse, JsonResponse
import json
import requests

from helloworld import settings




def show(request):
    if request.method == "GET":
        
        str1=(request.GET)
        str1=str(str1['query'])

        import requests
        import json

        # This is the url to which the query is made
        url = "https://data.attraction11.hasura-app.io/v1/query"

        # This is the json payload for the query
        requestPayload = {
             "type": "select",
    "args": {
        "table": "RepoTable",
        "columns": [
            "hashNum"
        ],
        "where": {
            "Domain": {
                "$eq": str1
            }
        }
    }
        }

        # Setting headers
        headers = {
            "Content-Type": "application/json"
        }

        # Make the query and store response in resp
        resp = requests.request("POST", url, data=json.dumps(requestPayload), headers=headers)
        a=str(resp.content)
        b=str(a)
        #b=b.split(":")
        #b=b[len(b)-1]
        #[{"hashNum":13}]
        b=b.replace(")","")
        b=b.replace("]","")
        b=b.replace("}","")
        b=b.replace("{","")
        b=b.replace("[","")
        b=b.replace("(","")
        b=b.replace('"',"")
        b=b.replace('hashNum',"")
        b=b.replace('b',"")
        b=b.replace("'","")
        b=b.replace(':',"")
        # resp.content contains the json response.
        #print resp.content
        ###########################calculatin gthe last hash

        
        return HttpResponse(b)
    else:
        return HttpResponse(" no get found")
        

def index(request):
    if request.method == "GET":
        
        str1=(request.GET)
        domain=str(str1['domain'])
        query=str(str1['query'])
        

        import requests
        import json

        # This is the url to which the query is made
        url = "https://data.attraction11.hasura-app.io/v1/query"

        # This is the json payload for the query
        requestPayload = {
            "type": "insert",
            "args": {
                "table": "RepoTable",
                "objects": [
                    {
                        "Domain": domain,
                        "query": query,
                        "Authorized": "false",
                        "Efficiency_Scale": "0"
                    }
                ]
            }
        }

        # Setting headers
        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer 27cc985aabc0df42c03747a51893c04e7ab9dd7e7d5a29f6",
            "X-Hasura-Role": "admin"
        }

        # Make the query and store response in resp
        resp = requests.request("POST", url, data=json.dumps(requestPayload), headers=headers)

        # resp.content contains the json response.
        #print resp.content        

        # resp.content contains the json response.
        #print resp.content
        import requests
        import json

        # This is the url to which the query is made
        url = "https://data.attraction11.hasura-app.io/v1/query"

        # This is the json payload for the query
        requestPayload = {
            "type": "select",
            "args": {
                "table": "RepoTable",
                "columns": [
                    "hashNum"
                ],
                "order_by": [
                    {
                        "column": "hashNum",
                        "order": "asc",
                        "Nones": "last"
                    }
                ]
            }
        }

        # Setting headers
        headers = {
            "Content-Type": "application/json"
        }

        # Make the query and store response in resp
        resp = requests.request("POST", url, data=json.dumps(requestPayload), headers=headers)
        a=str(resp.content)
        a=a.split(",")
        b=a[len(a)-1]
        b=str(b)
        b=b.split(":")
        b=b[len(b)-1]
        b=b.replace(")","")
        b=b.replace("]","")
        b=b.replace("}","")
        b=b.replace("'","")
        #https://app.attraction11.hasura-app.io/?query=testww&domain=yut
        # resp.content contains the json response.
        #print resp.content
##        from collections import OrderedDict
##        od = OrderedDict()
##        #OrderedDict([('b', 'f'), ('a', 'o'), ('r', 'o')])
##        ret=od.keys()[-1]
        
        
        return HttpResponse(b)
    else:
        return HttpResponse(" no get found")
        


